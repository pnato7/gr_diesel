// JS simples para interações futuras
console.log('GR Diesel site loaded');
